-- Organizations (INSERT IGNORE to avoid duplicate key errors on restart)
INSERT IGNORE INTO organization (organization_id, organization_name, org_code)
VALUES
(1, 'Cognizant', 'COG'),
(2, 'Wipro', 'WIP'),
(3, 'Zepto', 'ZEP');

-- Policies (Cognizant)
INSERT IGNORE INTO policy (policy_id, policy_name, policy_type, coverage_amount, base_premium,
                    organization_id, active, eligible_junior, eligible_senior)
VALUES
(1, 'Standard Individual Health', 'INDIVIDUAL', 500000, 5000, 1, 1, 1, 1),
(2, 'Family Health Shield', 'FAMILY', 1000000, 12000, 1, 1, 1, 0),
(3, 'Senior Leadership Plan', 'FAMILY', 2000000, 25000, 1, 1, 0, 1);

-- Policies (Wipro)
INSERT IGNORE INTO policy (policy_id, policy_name, policy_type, coverage_amount, base_premium,
                    organization_id, active, eligible_junior, eligible_senior)
VALUES
(4, 'Wipro Basic Health', 'INDIVIDUAL', 400000, 4500, 2, 1, 1, 1),
(5, 'Wipro Family Secure', 'FAMILY', 900000, 11000, 2, 1, 1, 0),
(6, 'Senior Leadership Plan', 'FAMILY', 1800000, 22000, 2, 1, 0, 1);

-- Policies (Zepto)
INSERT IGNORE INTO policy (policy_id, policy_name, policy_type, coverage_amount, base_premium,
                    organization_id, active, eligible_junior, eligible_senior)
VALUES
(7, 'Zepto Starter Health', 'INDIVIDUAL', 300000, 4000, 3, 1, 1, 1),
(8, 'Zepto Family Plus', 'FAMILY', 800000, 10000, 3, 1, 1, 1);
