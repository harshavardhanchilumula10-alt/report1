package com.employeeinsurancemanagement.model;

public enum EmployeeStatus{
    ACTIVE,NOTICE,EXITED
}