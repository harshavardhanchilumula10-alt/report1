package com.employeeinsurancemanagement.model;

public enum EnrollmentStatus {
    ACTIVE, INACTIVE ,CANCELLED
}
