package com.employeeinsurancemanagement.controller;

import com.employeeinsurancemanagement.dto.DependentDTO;
import com.employeeinsurancemanagement.dto.EnrollmentFormdto;
import com.employeeinsurancemanagement.model.Enrollment;
import com.employeeinsurancemanagement.service.EnrollmentService;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.EnrollmentRequest;
import com.employeeinsurancemanagement.model.Policy;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.repository.PolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/enrollments")
@RequiredArgsConstructor
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    private final PolicyRepository policyRepository;
    private final EmployeeRepository employeeRepository;

    @PostMapping("/process")
    public String process(
            @ModelAttribute("enrollmentForm") EnrollmentFormdto form,
            @RequestParam String action,
            Model model) {

        try {
            if ("addDependent".equals(action)) {
                if (form.getDependents().size() >= 8) {
                    model.addAttribute("error", "Cannot add more than 8 dependents");
                } else {
                    form.getDependents().add(new DependentDTO());
                }
            } else if (action.startsWith("removeDependent")) {
                try {
                    String[] parts = action.split(":");
                    if (parts.length == 2) {
                        int index = Integer.parseInt(parts[1]);
                        if (form.getDependents() != null && index >= 0 && index < form.getDependents().size()) {
                            form.getDependents().remove(index);
                        }
                    } else {
                        model.addAttribute("error", "Invalid remove action");
                    }
                } catch (NumberFormatException nfe) {
                    model.addAttribute("error", "Invalid dependent index");
                }
            } else if ("calculatePremium".equals(action)) {
                EnrollmentRequest request = createRequestFromForm(
                        form);
                double premium = enrollmentService.calculatePremium(request);
                form.setEstimatedPremium(premium);
            } else if ("enroll".equals(action)) {
                EnrollmentRequest request = createRequestFromForm(
                        form);
                Enrollment enrollment = enrollmentService.enroll(request);
                model.addAttribute("enrollment", enrollment);
                return "redirect:/employee/enrollments";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
        }

        prepareFormModel(model, form);
        return "employee/enrollmentForm";
    }

    private void prepareFormModel(Model model, EnrollmentFormdto form) {
        Policy policy = policyRepository.findById(form.getPolicyId())
                .orElseThrow(() -> new RuntimeException("Policy not found"));
        Employee employee = employeeRepository
                .findById(form.getEmployeeId())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        model.addAttribute("policy", policy);
        model.addAttribute("employee", employee);
        // contact details if needed, e.g. HR contact
    }

    private EnrollmentRequest createRequestFromForm(
            EnrollmentFormdto form) {
        EnrollmentRequest request = new EnrollmentRequest();
        request.setEmployeeId(form.getEmployeeId());
        request.setPolicyId(form.getPolicyId());
        request.setDependents(form.getDependents());
        return request;
    }

    @PostMapping("/{enrollmentId}/cancel")
    public String cancel(@PathVariable Long enrollmentId, Model model) {
        Enrollment enrollment = enrollmentService.cancel(enrollmentId);
        model.addAttribute("enrollment", enrollment);
        return "enrollmentDetail";
    }

    @GetMapping("/{enrollmentId}")
    public String getById(@PathVariable Long enrollmentId, Model model) {
        Enrollment enrollment = enrollmentService.getById(enrollmentId);
        model.addAttribute("enrollment", enrollment);
        return "enrollmentDetail";
    }

    @GetMapping("/employee/{employeeId}")
    public String getByEmployee(@PathVariable Long employeeId, Model model) {
        List<Enrollment> enrollments = enrollmentService.getByEmployee(employeeId);
        model.addAttribute("enrollments", enrollments);
        return "enrollmentList";
    }

    @GetMapping("/policy/{policyId}")
    public String getByPolicy(@PathVariable Long policyId, Model model) {
        List<Enrollment> enrollments = enrollmentService.getByPolicy(policyId);
        model.addAttribute("enrollments", enrollments);
        return "enrollmentList";

    }

    @GetMapping("/employee/enrollments")
    public String getEmployeeEnrollments(Model model) {
        // Add attributes: model.addAttribute("enrollments", ...);
        return "employee/enrollments";
    }
}