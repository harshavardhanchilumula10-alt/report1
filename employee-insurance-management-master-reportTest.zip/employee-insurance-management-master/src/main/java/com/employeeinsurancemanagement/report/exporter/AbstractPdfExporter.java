package com.employeeinsurancemanagement.service.exporter;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

/**
 * Base class for PDF exporters.
 * Provides common styling and utility methods.
 */
public abstract class AbstractPdfExporter {

    protected static final BaseColor HEADER_BG_BLUE = new BaseColor(52, 152, 219);
    protected static final BaseColor HEADER_BG_GREEN = new BaseColor(46, 204, 113);
    protected static final BaseColor HEADER_BG_YELLOW = new BaseColor(241, 196, 15);

    /**
     * Create title font.
     */
    protected Font createTitleFont() {
        return new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
    }

    /**
     * Create header font (white, bold).
     */
    protected Font createHeaderFont() {
        return new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
    }

    /**
     * Create data font.
     */
    protected Font createDataFont() {
        return new Font(Font.FontFamily.HELVETICA, 9);
    }

    /**
     * Create filter info font.
     */
    protected Font createFilterFont() {
        return new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);
    }

    /**
     * Create a styled header cell.
     */
    protected PdfPCell createHeaderCell(String text, Font font, BaseColor bgColor) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(bgColor);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(8);
        return cell;
    }

    /**
     * Add title to document.
     */
    protected void addTitle(Document document, String titleText) throws DocumentException {
        Paragraph title = new Paragraph(titleText, createTitleFont());
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(Chunk.NEWLINE);
    }

    /**
     * Get the header background color for this exporter.
     * Subclasses can override to customize.
     */
    protected BaseColor getHeaderBackgroundColor() {
        return HEADER_BG_BLUE;
    }
}
