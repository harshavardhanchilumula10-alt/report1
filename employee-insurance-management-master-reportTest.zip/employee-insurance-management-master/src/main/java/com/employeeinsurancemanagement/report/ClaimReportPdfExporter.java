package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractPdfExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Component
public class ClaimReportPdfExporter extends AbstractPdfExporter {

    public byte[] export(List<ClaimReportDto> data) {
        Document document = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            addTitle(document, "Claims Summary by Enrollment");

            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Headers
            Font headerFont = createHeaderFont();
            BaseColor headerBg = getHeaderBackgroundColor();
            String[] headers = { "Enrollment ID", "Claim ID", "Approved Amount", "Claim Date", "Status" };
            for (String h : headers) {
                table.addCell(createHeaderCell(h, headerFont, headerBg));
            }

            // Data
            Font dataFont = createDataFont();
            for (ClaimReportDto dto : data) {
                table.addCell(new Phrase("#" + dto.getEnrollmentId(), dataFont));
                table.addCell(new Phrase(dto.getClaimId() != null ? String.valueOf(dto.getClaimId()) : "-", dataFont));
                table.addCell(new Phrase(ReportFormatters.formatCurrency(dto.getApprovedAmount()), dataFont));
                table.addCell(new Phrase(ReportFormatters.formatDate(dto.getClaimDate()), dataFont));
                table.addCell(new Phrase(dto.getClaimStatus(), dataFont));
            }

            document.add(table);
            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}