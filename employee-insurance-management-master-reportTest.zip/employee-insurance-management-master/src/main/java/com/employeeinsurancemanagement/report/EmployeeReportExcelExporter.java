package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractExcelExporter;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EmployeeReportExcelExporter extends AbstractExcelExporter {

    public byte[] export(List<EmployeeReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Employees");

            CellStyle headerStyle = createHeaderStyle(workbook);

            // Header row
            createHeaderRow(sheet, headerStyle, "Org ID", "Org Name", "Employee Count");

            // Data rows
            int rowIdx = 1;
            for (EmployeeReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getOrganizationId());
                row.createCell(1).setCellValue(dto.getOrganizationName());
                row.createCell(2).setCellValue(dto.getEmployeeCount());
            }

            autoSizeColumns(sheet, 3);
            return writeToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
