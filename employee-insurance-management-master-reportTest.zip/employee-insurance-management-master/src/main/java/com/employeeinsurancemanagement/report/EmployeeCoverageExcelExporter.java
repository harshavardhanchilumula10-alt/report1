package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeCoverageReportDTO;
import com.employeeinsurancemanagement.service.exporter.AbstractExcelExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Excel exporter for Employee Coverage Report.
 * Exports filtered data to XLSX format.
 */
@Component
public class EmployeeCoverageExcelExporter extends AbstractExcelExporter {

    public byte[] export(List<EmployeeCoverageReportDTO> data, String filters) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Employee Coverage Report");

            CellStyle headerStyle = createHeaderStyle(workbook);

            // Add filter info row
            Row filterRow = sheet.createRow(0);
            Cell filterCell = filterRow.createCell(0);
            filterCell.setCellValue("Applied Filters: " + filters);

            // Empty row
            sheet.createRow(1);

            // Create header row
            Row header = sheet.createRow(2);
            String[] columns = { "Employee Code", "Name", "Email", "Designation", "Joining Date",
                    "Category", "Status", "Enrolled", "Active Policies" };
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            // Add data rows
            int rowIdx = 3;
            for (EmployeeCoverageReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEmployeeCode());
                row.createCell(1).setCellValue(dto.getEmployeeName());
                row.createCell(2).setCellValue(dto.getEmail());
                row.createCell(3).setCellValue(dto.getDesignation());
                row.createCell(4).setCellValue(ReportFormatters.formatDate(dto.getJoiningDate()));
                row.createCell(5).setCellValue(dto.getCategory().name());
                row.createCell(6).setCellValue(dto.getStatus().name());
                row.createCell(7).setCellValue(dto.isEnrolled() ? "Yes" : "No");
                row.createCell(8).setCellValue(dto.getActiveEnrollmentCount());
            }

            autoSizeColumns(sheet, columns.length);
            return writeToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
