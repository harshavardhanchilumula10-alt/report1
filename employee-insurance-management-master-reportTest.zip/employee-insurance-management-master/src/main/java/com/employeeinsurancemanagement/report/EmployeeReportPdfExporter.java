package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractPdfExporter;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Component
public class EmployeeReportPdfExporter extends AbstractPdfExporter {

    public byte[] export(List<EmployeeReportDto> data) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            addTitle(document, "Employee Report");

            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Headers
            Font headerFont = createHeaderFont();
            BaseColor headerBg = getHeaderBackgroundColor();
            String[] headers = { "Org ID", "Org Name", "Employee Count" };
            for (String h : headers) {
                table.addCell(createHeaderCell(h, headerFont, headerBg));
            }

            // Data
            Font dataFont = createDataFont();
            for (EmployeeReportDto dto : data) {
                table.addCell(new Phrase(String.valueOf(dto.getOrganizationId()), dataFont));
                table.addCell(new Phrase(dto.getOrganizationName(), dataFont));
                table.addCell(new Phrase(String.valueOf(dto.getEmployeeCount()), dataFont));
            }

            document.add(table);
            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
