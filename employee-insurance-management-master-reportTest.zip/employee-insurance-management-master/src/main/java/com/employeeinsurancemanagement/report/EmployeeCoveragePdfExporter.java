package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeCoverageReportDTO;
import com.employeeinsurancemanagement.model.EmployeeStatus;
import com.employeeinsurancemanagement.service.exporter.AbstractPdfExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * PDF exporter for Employee Coverage Report.
 * Exports filtered data to PDF format.
 */
@Component
public class EmployeeCoveragePdfExporter extends AbstractPdfExporter {

    @Override
    protected BaseColor getHeaderBackgroundColor() {
        return HEADER_BG_GREEN;
    }

    public byte[] export(List<EmployeeCoverageReportDTO> data, String filters) {
        Document document = new Document(PageSize.A4.rotate()); // Landscape for more columns
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            addTitle(document, "Employee Coverage Report");

            // Filters info
            Paragraph filterInfo = new Paragraph("Applied Filters: " + filters, createFilterFont());
            document.add(filterInfo);
            document.add(Chunk.NEWLINE);

            // Create table with 8 columns
            PdfPTable table = new PdfPTable(8);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Add headers
            Font headerFont = createHeaderFont();
            BaseColor headerBg = getHeaderBackgroundColor();
            String[] headers = { "Code", "Name", "Email", "Designation", "Joining Date",
                    "Category", "Status", "Enrolled" };
            for (String h : headers) {
                table.addCell(createHeaderCell(h, headerFont, headerBg));
            }

            // Data
            Font dataFont = createDataFont();
            for (EmployeeCoverageReportDTO dto : data) {
                table.addCell(new Phrase(dto.getEmployeeCode(), dataFont));
                table.addCell(new Phrase(dto.getEmployeeName(), dataFont));
                table.addCell(new Phrase(dto.getEmail(), dataFont));
                table.addCell(new Phrase(dto.getDesignation() != null ? dto.getDesignation() : "-", dataFont));
                table.addCell(new Phrase(ReportFormatters.formatDate(dto.getJoiningDate()), dataFont));
                table.addCell(new Phrase(dto.getCategory().name(), dataFont));

                // Status with color - using enum comparison
                PdfPCell statusCell = new PdfPCell(new Phrase(dto.getStatus().name(), dataFont));
                if (dto.getStatus() == EmployeeStatus.ACTIVE) {
                    statusCell.setBackgroundColor(new BaseColor(200, 255, 200));
                } else if (dto.getStatus() == EmployeeStatus.EXITED) {
                    statusCell.setBackgroundColor(new BaseColor(255, 200, 200));
                } else {
                    statusCell.setBackgroundColor(new BaseColor(255, 255, 200));
                }
                table.addCell(statusCell);

                // Enrollment with color
                PdfPCell enrollCell = new PdfPCell(
                        new Phrase(dto.isEnrolled() ? "Yes (" + dto.getActiveEnrollmentCount() + ")" : "No", dataFont));
                enrollCell.setBackgroundColor(dto.isEnrolled() ? new BaseColor(200, 220, 255) : BaseColor.WHITE);
                table.addCell(enrollCell);
            }

            document.add(table);

            // Footer with count
            document.add(Chunk.NEWLINE);
            Font footerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
            document.add(new Paragraph("Total Employees: " + data.size(), footerFont));

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
