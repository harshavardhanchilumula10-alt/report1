package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.PremiumReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractExcelExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PremiumReportExcelExporter extends AbstractExcelExporter {

    public byte[] export(List<PremiumReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Premium Report");

            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle currencyStyle = createCurrencyCellStyle(workbook);

            // Header row
            createHeaderRow(sheet, headerStyle,
                    "Organization ID", "Organization Name", "Total Premium Collected");

            // Data rows
            int rowIdx = 1;
            for (PremiumReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getOrganizationId());
                row.createCell(1).setCellValue(dto.getOrganizationName());

                Cell premiumCell = row.createCell(2);
                premiumCell.setCellValue(ReportFormatters.formatCurrencyRaw(dto.getTotalPremiumCollected()));
                premiumCell.setCellStyle(currencyStyle);
            }

            autoSizeColumns(sheet, 3);
            return writeToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
