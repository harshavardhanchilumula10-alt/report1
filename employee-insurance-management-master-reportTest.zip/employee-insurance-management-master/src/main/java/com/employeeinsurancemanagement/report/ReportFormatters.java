package com.employeeinsurancemanagement.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Centralized formatting utilities for reports.
 * Ensures consistent date and currency formatting across all exporters.
 */
public final class ReportFormatters {

    public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    private ReportFormatters() {
        // Utility class - no instantiation
    }

    /**
     * Format a LocalDate to dd-MM-yyyy string.
     * Returns "-" if date is null.
     */
    public static String formatDate(LocalDate date) {
        return date != null ? date.format(DATE_FORMAT) : "-";
    }

    /**
     * Format a currency value with ₹ symbol.
     * Returns "₹0.00" if value is null.
     */
    public static String formatCurrency(Double value) {
        return "₹" + String.format("%,.2f", value != null ? value : 0.0);
    }

    /**
     * Format a currency value as raw number (for Excel numeric cells).
     */
    public static double formatCurrencyRaw(Double value) {
        return value != null ? value : 0.0;
    }
}
