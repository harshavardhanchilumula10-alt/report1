package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractExcelExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ClaimReportExcelExporter extends AbstractExcelExporter {

    public byte[] export(List<ClaimReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Claims Summary");

            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle currencyStyle = createCurrencyCellStyle(workbook);

            // Header row
            createHeaderRow(sheet, headerStyle,
                    "Enrollment ID", "Claim ID", "Approved Amount", "Claim Date", "Status");

            // Data rows
            int rowIdx = 1;
            for (ClaimReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);

                row.createCell(0).setCellValue(dto.getEnrollmentId());

                Cell claimIdCell = row.createCell(1);
                if (dto.getClaimId() != null) {
                    claimIdCell.setCellValue(dto.getClaimId());
                } else {
                    claimIdCell.setCellValue("-");
                }

                Cell amountCell = row.createCell(2);
                amountCell.setCellValue(ReportFormatters.formatCurrencyRaw(dto.getApprovedAmount()));
                amountCell.setCellStyle(currencyStyle);

                row.createCell(3).setCellValue(ReportFormatters.formatDate(dto.getClaimDate()));

                row.createCell(4).setCellValue(dto.getClaimStatus());
            }

            autoSizeColumns(sheet, 5);
            return writeToBytes(workbook);
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
