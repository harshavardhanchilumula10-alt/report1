package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.PremiumReportDto;
import com.employeeinsurancemanagement.service.exporter.AbstractPdfExporter;
import com.employeeinsurancemanagement.util.ReportFormatters;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Component
public class PremiumReportPdfExporter extends AbstractPdfExporter {

    @Override
    protected BaseColor getHeaderBackgroundColor() {
        return HEADER_BG_YELLOW;
    }

    public byte[] export(List<PremiumReportDto> data) {
        Document document = new Document(PageSize.A4);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            addTitle(document, "Premium Collected by Organization");

            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Headers
            Font headerFont = createHeaderFont();
            BaseColor headerBg = getHeaderBackgroundColor();
            String[] headers = { "Organization ID", "Organization Name", "Total Premium Collected" };
            for (String h : headers) {
                table.addCell(createHeaderCell(h, headerFont, headerBg));
            }

            // Data
            Font dataFont = createDataFont();
            for (PremiumReportDto dto : data) {
                table.addCell(new Phrase(String.valueOf(dto.getOrganizationId()), dataFont));
                table.addCell(new Phrase(dto.getOrganizationName(), dataFont));
                table.addCell(new Phrase(ReportFormatters.formatCurrency(dto.getTotalPremiumCollected()), dataFont));
            }

            document.add(table);
            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
