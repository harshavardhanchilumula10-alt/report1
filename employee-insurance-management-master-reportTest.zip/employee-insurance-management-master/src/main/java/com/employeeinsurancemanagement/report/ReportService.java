package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.dto.PremiumReportDto;

import java.util.List;

/**
 * Service interface for report data retrieval.
 * Note: All data queries are implemented in ReportServiceImpl using
 * EntityManager.
 */
public interface ReportService {

  /**
   * Get employee count grouped by organization.
   * 
   * @param organizationId filter by org ID, or null for all
   */
  List<EmployeeReportDto> getEmployeeCountByOrganization(Long organizationId);

  /**
   * Get claim summary grouped by enrollment.
   * 
   * @param status filter by claim status, or null/ALL for all
   */
  List<ClaimReportDto> getClaimSummaryByEnrollment(String status);

  /**
   * Get total premium collected grouped by organization.
   * 
   * @param organizationId filter by org ID, or null for all
   */
  List<PremiumReportDto> getPremiumCollectedByOrganization(Long organizationId);
}
