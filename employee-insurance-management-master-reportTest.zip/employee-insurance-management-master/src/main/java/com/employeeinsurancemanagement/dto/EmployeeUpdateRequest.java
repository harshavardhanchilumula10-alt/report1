package com.employeeinsurancemanagement.dto;

import com.employeeinsurancemanagement.model.EmployeeAddress;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

/**
 * DTO for employee self-service profile updates.
 * ONLY these fields can be updated by employee:
 * - Name, Phone, Address
 *
 * NOT allowed: Email, Joining Date, Category, Status, Organization
 */
@Getter
@Setter
public class EmployeeUpdateRequest {

    @NotBlank(message = "Name is required")
    @Size(min = 3, max = 50, message = "Name must be 3-50 characters")
    private String employeeName;

    @Pattern(regexp = "^[6-9][0-9]{9}$", message = "Must be a valid 10-digit Indian mobile number")
    private String phoneNumber;

    @Valid
    @NotNull(message = "Address is required")
    private EmployeeAddress address;
}
