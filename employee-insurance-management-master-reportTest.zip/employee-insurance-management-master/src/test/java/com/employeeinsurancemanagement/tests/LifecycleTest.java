package com.employeeinsurancemanagement.tests;

import com.employeeinsurancemanagement.dto.EmployeeCreateRequest;

import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.model.EmployeeAddress;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.Organization;
import com.employeeinsurancemanagement.model.User;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.repository.OrganizationRepository;
import com.employeeinsurancemanagement.repository.UserRepository;
import com.employeeinsurancemanagement.service.EmployeeServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class LifecycleTest {

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private OrganizationRepository organizationRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private SecurityContext securityContext;
    @Mock
    private Authentication authentication;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        SecurityContextHolder.setContext(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("hr@company.com");
    }

    private void mockCurrentUser(User.Role role) {
        User user = new User();
        user.setEmail("hr@company.com");
        user.setRole(role);
        when(userRepository.findByEmail(any())).thenReturn(Optional.of(user));

        when(authentication.getName()).thenReturn("hr@company.com");
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    @Test
    void testActiveToExited_ShouldFail() {
        mockCurrentUser(User.Role.HR);

        Employee activeEmployee = new Employee();
        activeEmployee.setEmployeeId(1L);
        activeEmployee.setStatus(com.employeeinsurancemanagement.model.EmployeeStatus.ACTIVE);

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(activeEmployee));

        // Attempting to Exit directly should fail (Must be in NOTICE)
        Assertions.assertThrows(BusinessException.class, () -> {
            employeeService.exitEmployee(1L);
        });
    }

    @Test
    void testActiveToNoticeToExited_ShouldPass() {
        mockCurrentUser(User.Role.HR);

        Employee employee = new Employee();
        employee.setEmployeeId(1L);
        employee.setStatus(com.employeeinsurancemanagement.model.EmployeeStatus.ACTIVE);

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

        // 1. Resign (Active -> Notice)
        employeeService.resignEmployee(1L, LocalDate.now());
        Assertions.assertEquals(com.employeeinsurancemanagement.model.EmployeeStatus.NOTICE, employee.getStatus());

        // 2. Fast forward notice period end date for testing
        employee.setNoticePeriodEndDate(LocalDate.now().minusDays(1));

        // 3. Exit (Notice -> Exited)
        employeeService.exitEmployee(1L);
        Assertions.assertEquals(com.employeeinsurancemanagement.model.EmployeeStatus.EXITED, employee.getStatus());
    }

    @Test
    void testJoiningDateInFuture_ShouldFail() {
        mockCurrentUser(User.Role.HR);

        EmployeeCreateRequest req = new EmployeeCreateRequest();
        req.setEmployeeName("Future Boy");
        req.setEmail("future@company.com");
        req.setDateOfBirth(LocalDate.of(2000, 1, 1));
        req.setJoiningDate(LocalDate.now().plusDays(10)); // Future Date
        req.setPhoneNumber("9999999999");
        req.setDesignation("Dev");
        req.setPassword("password");
        req.setAddress(new EmployeeAddress());

        // Organization Mock
        when(organizationRepository.findById(1L)).thenReturn(Optional.of(new Organization()));
        when(employeeRepository.findByEmail(any())).thenReturn(Optional.empty());

        Assertions.assertThrows(BusinessException.class, () -> {
            employeeService.registerEmployee(req, 1L);
        }, "Should not allow joining date in future");
    }
}
