# Report Module Documentation

## Overview

The Report Module generates analytical reports for the Employee Insurance Management System. It provides both **on-screen data display** and **downloadable exports** in PDF and Excel formats.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        CONTROLLERS                               │
│   HrController, AdminController (handle HTTP requests)          │
└──────────────────────────┬──────────────────────────────────────┘
                           │ calls
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                       REPORT SERVICE                             │
│   ReportService (interface) → ReportServiceImpl (implementation)│
│   - Queries database using EntityManager (JPQL)                 │
│   - Returns List<DTO> for display                               │
│   - Delegates to Exporters for file generation                  │
└──────────────────────────┬──────────────────────────────────────┘
                           │ uses
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                        EXPORTERS                                 │
│   PremiumReportPdfExporter    PremiumReportExcelExporter        │
│   EmployeeReportPdfExporter   EmployeeReportExcelExporter       │
│   ClaimReportPdfExporter      ClaimReportExcelExporter          │
│   EmployeeCoveragePdfExporter EmployeeCoverageExcelExporter     │
└──────────────────────────┬──────────────────────────────────────┘
                           │ uses
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                     EXTERNAL LIBRARIES                           │
│   iTextPDF (PDF generation)  |  Apache POI (Excel generation)  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Key Components

### 1. DTOs (Data Transfer Objects)

| DTO | Purpose | Fields |
|-----|---------|--------|
| `EmployeeReportDto` | Employee count per organization | organizationId, organizationName, employeeCount |
| `PremiumReportDto` | Premium collected per organization | organizationId, organizationName, totalPremiumCollected |
| `ClaimReportDto` | Claims by enrollment | enrollmentId, claimId, approvedAmount, claimDate, claimStatus |
| `EmployeeCoverageReportDTO` | Employee insurance coverage details | Employee coverage information |

---

### 2. ReportService Interface & Implementation

**Data Methods** (return DTOs for UI display):
```java
getEmployeeCountByOrganization(Long orgId)    // Employees per organization
getPremiumCollectedByOrganization(Long orgId) // Premium totals
getClaimSummaryByEnrollment(String status)    // Claims with optional filter
```

**Export Methods** (return byte[] for download):
```java
exportEmployeeReportExcel()  →  byte[] (XLSX file)
exportEmployeeReportPdf()    →  byte[] (PDF file)
exportPremiumReportExcel()   →  byte[] (XLSX file)
exportPremiumReportPdf()     →  byte[] (PDF file)
exportClaimReportExcel()     →  byte[] (XLSX file)
exportClaimReportPdf()       →  byte[] (PDF file)
```

---

### 3. Exporters (File Generators)

**PDF Exporters** - Use **iTextPDF** library:
- Create `Document` with page size (A4)
- Add title, headers, data table
- Style with fonts, colors, padding
- Return as `byte[]`

**Excel Exporters** - Use **Apache POI** library:
- Create `XSSFWorkbook` 
- Create sheets, rows, cells
- Apply styles (bold headers, borders)
- Write to `ByteArrayOutputStream`
- Return as `byte[]`

---

## Report Generation Flow

```
1. USER clicks "Export PDF" button on /hr/reports page

2. BROWSER sends GET request to /hr/reports/premium/export/pdf

3. HrController.exportPremiumReportPdf() handles request:
   │
   ├─► Calls reportService.getPremiumCollectedByOrganization(orgId)
   │      │
   │      └─► ReportServiceImpl runs JPQL query:
   │            SELECT new PremiumReportDto(...)
   │            FROM Organization o...
   │      │
   │      └─► Returns List<PremiumReportDto>
   │
   ├─► Creates new PremiumReportPdfExporter()
   │      │
   │      └─► exporter.export(data):
   │            - Creates iTextPDF Document
   │            - Adds title
   │            - Creates table with headers
   │            - Loops through DTOs, adds rows
   │            - Returns byte[]
   │
   └─► Sets HTTP response:
         response.setContentType("application/pdf")
         response.setHeader("Content-Disposition", "attachment;...")
         response.getOutputStream().write(pdfBytes)

4. BROWSER downloads the PDF file
```

---

## Report Types Available

| Report | URL Pattern | Formats | Description |
|--------|-------------|---------|-------------|
| **Employee Count** | `/hr/employees-report/export/*` | PDF, Excel | Employees per organization |
| **Premium Collected** | `/hr/reports/premium/export/*` | PDF, Excel | Total premiums by organization |
| **Claims Summary** | `/hr/reports/claims/export/*` | PDF, Excel | Claims with filtering/sorting |
| **Employee Coverage** | `/hr/coverage-report/export/*` | PDF, Excel | Employee insurance details |

---

## Libraries Used

### 1. iTextPDF (`com.itextpdf`)
For PDF generation:
- `Document` - Main PDF container
- `PdfWriter` - Writes document to output stream
- `PdfPTable` / `PdfPCell` - Table creation
- `Font`, `BaseColor` - Styling

### 2. Apache POI (`org.apache.poi`)
For Excel generation:
- `XSSFWorkbook` - XLSX workbook
- `Sheet`, `Row`, `Cell` - Structure
- `CellStyle` - Formatting

---

## Error Handling

When report generation fails:
```java
catch (Exception e) {
    throw new ReportGenerationException("PDF generation failed", e);
}
```

Caught by `GlobalExceptionHandler` → displays user-friendly message.

---

## File Locations

| Component | Path |
|-----------|------|
| Service Interface | `service/ReportService.java` |
| Service Implementation | `service/ReportServiceImpl.java` |
| PDF Exporters | `service/*PdfExporter.java` |
| Excel Exporters | `service/*ExcelExporter.java` |
| DTOs | `dto/*ReportDto.java` |
| Custom Exception | `exception/ReportGenerationException.java` |
