package com.employeeinsurancemanagement.premium.service;

import com.employeeinsurancemanagement.model.Employee.EmployeeCategory;
import com.employeeinsurancemanagement.model.PolicyType;
import com.employeeinsurancemanagement.model.PremiumInput;
import com.employeeinsurancemanagement.service.PremiumCalculatorService;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PremiumCalculatorServiceTest {

    private final PremiumCalculatorService calculator = new PremiumCalculatorService();

    @Test
    void premium_should_not_exceed_180_percent() {
        PremiumInput input = new PremiumInput();
        input.setBasePremium(1000.0);
        input.setAge(60); // High risk (+1200)
        input.setPolicyType(PolicyType.FAMILY); // (+1200)
        input.setPastClaimsCount(5); // (+1500)
        input.setCoverageAmount(2000000.0); // (+1800)
        input.setTenureYears(0);
        input.setCategory(EmployeeCategory.JUNIOR);

        // Expected calculation without cap:
        // 1000 + 1200 + 1200 + 1500 + 1800 = 6700
        // Cap is 1.8 * 1000 = 1800.

        double premium = calculator.calculatePremium(input);

        // Using assertEquals for stricter check, but user asked for assertTrue(<=)
        assertTrue(premium <= input.getBasePremium() * 1.8, "Premium should be capped at 180%");
        assertEquals(1800.0, premium, "Premium should be exactly 1800 due to cap");
    }

    @Test
    void verify_standard_calculation() {
        PremiumInput input = new PremiumInput();
        input.setBasePremium(1000.0);
        input.setAge(25); // <30 (+200)
        input.setPolicyType(PolicyType.INDIVIDUAL); // (0)
        input.setPastClaimsCount(0); // (0)
        input.setCoverageAmount(400000.0); // <= 500k (+500)
        input.setTenureYears(2); // <5 (0)
        input.setCategory(EmployeeCategory.JUNIOR); // (0)

        // Total: 1000 + 200 + 500 = 1700
        // Min cap: 1000 * 0.8 = 800
        // Max cap: 1000 * 1.8 = 1800
        // Result 1700 is within range.

        double premium = calculator.calculatePremium(input);
        assertEquals(1700.0, premium);
    }
}
