package com.employeeinsurancemanagement.integration;

import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.model.*;
import com.employeeinsurancemanagement.model.Employee.EmployeeCategory;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.repository.OrganizationRepository;
import com.employeeinsurancemanagement.repository.PolicyRepository;
import com.employeeinsurancemanagement.service.ClaimService;
import com.employeeinsurancemanagement.service.EnrollmentService;
import com.employeeinsurancemanagement.model.EnrollmentRequest;

import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class ClaimValidationTest {

    @Autowired
    private ClaimService claimService;

    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private PolicyRepository policyRepository;

    private Employee employee;
    private Policy policy;
    private Enrollment enrollment;

    @BeforeEach
    void setup() {
        // 1. Ensure Organization
        Organization org = organizationRepository.findByOrganizationName("Cognizant")
                .orElseThrow(() -> new RuntimeException("Org not found"));

        // 2. Create Employee
        employee = new Employee();
        employee.setEmployeeName("Validation Tester");
        employee.setOrganization(org);
        employee.setEmployeeCategory(EmployeeCategory.JUNIOR);
        employee.setStatus(EmployeeStatus.ACTIVE);
        employee.setEmail("validation@tester.com");
        employee.setDesignation("Tester");
        employee.setDateOfBirth(LocalDate.of(1990, 1, 1));
        employee.setEmployeeSeq(System.currentTimeMillis());
        employee = employeeRepository.save(employee);

        // 3. Ensure Policy (Cognizant JUNIOR)
        List<Policy> policies = policyRepository.findAll();
        policy = policies.stream()
                .filter(p -> p.getOrganization().getOrganizationName().equals("Cognizant"))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No Cognizant policy found"));

        // Ensure coverage is exactly 50,000 for predictable testing
        policy.setCoverageAmount(50000.0);
        policyRepository.save(policy);

        // 4. Enroll
        EnrollmentRequest request = new EnrollmentRequest();
        request.setEmployeeId(employee.getEmployeeId());
        request.setPolicyId(policy.getPolicyId());
        request.setDependents(new ArrayList<>());

        enrollment = enrollmentService.enroll(request);
    }

    @Test
    void testSubmitValidClaim() {
        double amount = 10000.0;
        String reason = "Valid Test Claim";

        Claim claim = claimService.submitClaim(employee.getEmployeeId(), enrollment.getEnrollmentId(), amount, reason);

        assertNotNull(claim);
        assertEquals(amount, claim.getClaimAmount());
        assertEquals(ClaimStatus.SUBMITTED, claim.getClaimStatus());
    }

    @Test
    void testSubmitClaimExceedingCoverage() {
        // Coverage is 50,000.
        // Max Claimable = 50,000 / 0.8 = 62,500.
        // Submit 70,000.

        double excessiveAmount = 70000.0;
        String reason = "Excessive Claim";

        Exception exception = assertThrows(BusinessException.class, () -> {
            claimService.submitClaim(employee.getEmployeeId(), enrollment.getEnrollmentId(), excessiveAmount, reason);
        });

        // Verify message
        assertTrue(exception.getMessage().toLowerCase().contains("exceed"));
    }

    @Test
    void testSubmitClaimExceedingRemainingBalance() {
        // 1. Submit a large claim first to drain coverage
        // Submit 60,000.
        // Approved = min(60000*0.8, 50000) = min(48000, 50000) = 48,000.
        // Remaining = 50,000 - 48,000 = 2,000.

        Claim c1 = claimService.submitClaim(employee.getEmployeeId(), enrollment.getEnrollmentId(), 60000.0,
                "First Claim");
        claimService.approveClaim(c1.getClaimId()); // Reduce balance

        // 2. Try to claim 3,000.
        // Max Claimable = 2,000 / 0.8 = 2,500.
        // 3,000 > 2,500. Should fail.

        double secondAmount = 3000.0;

        Exception exception = assertThrows(BusinessException.class, () -> {
            claimService.submitClaim(employee.getEmployeeId(), enrollment.getEnrollmentId(), secondAmount,
                    "Balance Exceeded Claim");
        });

        assertTrue(exception.getMessage().toLowerCase().contains("exceed"));
    }

    // Optional: Test negative amount if logic exists
}
