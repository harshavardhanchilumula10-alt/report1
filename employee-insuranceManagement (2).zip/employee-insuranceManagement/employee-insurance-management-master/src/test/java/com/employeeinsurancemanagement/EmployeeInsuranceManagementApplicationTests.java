package com.employeeinsurancemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeInsuranceManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
