package com.employeeinsurancemanagement.tests;

import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.model.*;
import com.employeeinsurancemanagement.repository.ClaimRepository;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.repository.PolicyRepository;
import com.employeeinsurancemanagement.service.ClaimServiceImpl;
import com.employeeinsurancemanagement.service.EnrollmentServiceImpl;
import com.employeeinsurancemanagement.service.PremiumCalculatorService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class BusinessRulesTest {

    @InjectMocks
    private EnrollmentServiceImpl enrollmentService;
    @InjectMocks
    private ClaimServiceImpl claimService;

    @Mock
    private EnrollmentRepository enrollmentRepository;
    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private PolicyRepository policyRepository;
    @Mock
    private ClaimRepository claimRepository;
    @Mock
    private PremiumCalculatorService premiumCalculatorService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testDoubleEnrollment_ShouldFail() {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setEmployeeId(1L);
        req.setPolicyId(1L);

        Employee emp = new Employee();
        emp.setEmployeeId(1L);
        emp.setStatus(EmployeeStatus.ACTIVE);
        // Organization setup
        Organization org = new Organization();
        org.setOrganizationId(100L);
        emp.setOrganization(org);

        Policy policy = new Policy();
        policy.setPolicyId(1L);
        policy.setOrganization(org);

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(emp));
        when(policyRepository.findById(1L)).thenReturn(Optional.of(policy));

        // Mock existing enrollment for same policy
        when(enrollmentRepository.findByEmployeeAndPolicy(emp, policy))
                .thenReturn(Optional.of(new Enrollment()));

        Assertions.assertThrows(BusinessException.class, () -> {
            enrollmentService.enroll(req);
        }, "Should block double enrollment");
    }

    @Test
    void testClaimExceedsMaxClaimable_ShouldFail() {
        // Setup: Policy Coverage = 1000. 80% Rule.
        // Max Claimable = 1000 / 0.8 = 1250.
        // If Claim = 1300 -> Payout 1040 (Exceeds 1000). Should Fail.

        Employee emp = new Employee();
        emp.setEmployeeId(1L);

        Policy policy = new Policy();
        policy.setCoverageAmount(1000.0);

        Enrollment enrollment = new Enrollment();
        enrollment.setEnrollmentId(1L);
        enrollment.setEmployee(emp);
        enrollment.setPolicy(policy);
        enrollment.setEnrollmentStatus(EnrollmentStatus.ACTIVE);
        enrollment.setUsedAmount(0.0);

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(emp));
        when(enrollmentRepository.findById(1L)).thenReturn(Optional.of(enrollment));
        // No pending claims
        when(claimRepository.existsActiveClaimForEnrollment(any(), any(), any())).thenReturn(false);

        // Attempt Claim 1300
        Assertions.assertThrows(BusinessException.class, () -> {
            claimService.submitClaim(1L, 1L, 1300.0, "High Claim");
        }, "Claim exceeding coverage limit should be blocked");
    }

    @Test
    void testClaimApproval_UpdatesBalance() {
        // Setup: Claim 1000. Coverage 2000. Used 0.
        // Payout = 800. New Used = 800.

        Claim claim = new Claim();
        claim.setClaimId(10L);
        claim.setClaimAmount(1000.0);
        claim.setClaimStatus(ClaimStatus.SUBMITTED);

        Policy policy = new Policy();
        policy.setCoverageAmount(2000.0);

        Enrollment enrollment = new Enrollment();
        enrollment.setEnrollmentId(1L);
        enrollment.setPolicy(policy);
        enrollment.setUsedAmount(0.0);

        claim.setEnrollment(enrollment);

        when(claimRepository.findById(10L)).thenReturn(Optional.of(claim));
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> i.getArguments()[0]);
        when(enrollmentRepository.save(any(Enrollment.class))).thenAnswer(i -> i.getArguments()[0]);

        Claim approved = claimService.approveClaim(10L);

        Assertions.assertEquals(800.0, approved.getApprovedAmount());
        Assertions.assertEquals(800.0, enrollment.getUsedAmount());
        Assertions.assertEquals(ClaimStatus.APPROVED, approved.getClaimStatus());
    }

    @Test
    void testEnrollment_NoticePeriodEmployee_ShouldFail() {
        EnrollmentRequest req = new EnrollmentRequest();
        req.setEmployeeId(1L);
        req.setPolicyId(1L);

        Employee emp = new Employee();
        emp.setEmployeeId(1L);
        emp.setStatus(EmployeeStatus.NOTICE);
        // Organization setup
        Organization org = new Organization();
        org.setOrganizationId(100L);
        emp.setOrganization(org);

        Policy policy = new Policy();
        policy.setPolicyId(1L);
        policy.setOrganization(org);

        when(employeeRepository.findById(1L)).thenReturn(Optional.of(emp));
        when(policyRepository.findById(1L)).thenReturn(Optional.of(policy));

        // Mock that the employee has 0 current enrollments so we don't hit the "max 2
        // policies" check first
        when(enrollmentRepository.findByEmployee(emp)).thenReturn(java.util.Collections.emptyList());

        // Also strict check: Organization of policy must match employee
        // In this test setup, both have orgId 100L, so that check passes.

        Assertions.assertThrows(BusinessException.class, () -> {
            enrollmentService.enroll(req);
        }, "Should block notice period enrollment");
    }
}
