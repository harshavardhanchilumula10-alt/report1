package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.exception.ReportGenerationException;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class EmployeeReportPdfExporter {

    public byte[] export(List<EmployeeReportDto> data) {

        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            document.add(new Paragraph("Employee Report"));
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(3);
            table.addCell("Org ID");
            table.addCell("Org Name");
            table.addCell("Employee Count");

            for (EmployeeReportDto dto : data) {
                table.addCell(String.valueOf(dto.getOrganizationId()));
                table.addCell(dto.getOrganizationName());
                table.addCell(String.valueOf(dto.getEmployeeCount()));
            }

            document.add(table);
            document.close();
        } catch (Exception e) {
            throw new ReportGenerationException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
