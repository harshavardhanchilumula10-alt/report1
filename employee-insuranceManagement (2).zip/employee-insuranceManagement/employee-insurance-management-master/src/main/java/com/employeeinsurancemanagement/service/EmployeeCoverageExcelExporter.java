package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeCoverageReportDTO;
import com.employeeinsurancemanagement.exception.ReportGenerationException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * Excel exporter for Employee Coverage Report.
 * Exports filtered data to XLSX format.
 */
public class EmployeeCoverageExcelExporter {

    public byte[] export(List<EmployeeCoverageReportDTO> data, String filters) {
        try (Workbook workbook = new XSSFWorkbook();
                ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Employee Coverage Report");

            // Create header style
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Add filter info row
            Row filterRow = sheet.createRow(0);
            Cell filterCell = filterRow.createCell(0);
            filterCell.setCellValue("Applied Filters: " + filters);

            // Empty row
            sheet.createRow(1);

            // Create header row
            Row header = sheet.createRow(2);
            String[] columns = { "Employee Code", "Name", "Email", "Designation", "Joining Date",
                    "Category", "Status", "Enrolled", "Active Policies" };
            for (int i = 0; i < columns.length; i++) {
                Cell cell = header.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            // Add data rows
            int rowIdx = 3;
            for (EmployeeCoverageReportDTO dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEmployeeCode());
                row.createCell(1).setCellValue(dto.getEmployeeName());
                row.createCell(2).setCellValue(dto.getEmail());
                row.createCell(3).setCellValue(dto.getDesignation());
                row.createCell(4).setCellValue(dto.getJoiningDate() != null ? dto.getJoiningDate().toString() : "N/A");
                row.createCell(5).setCellValue(dto.getCategory().name());
                row.createCell(6).setCellValue(dto.getStatus().name());
                row.createCell(7).setCellValue(dto.isEnrolled() ? "Yes" : "No");
                row.createCell(8).setCellValue(dto.getActiveEnrollmentCount());
            }

            // Auto-size columns
            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new ReportGenerationException("Excel generation failed", e);
        }
    }
}
