package com.employeeinsurancemanagement.dto;

import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.EmployeeStatus;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

/**
 * Read-only DTO for HR employee coverage reports.
 * Prevents accidental writes and isolates view logic.
 */
@Getter
@Builder
public class EmployeeCoverageReportDTO {

    private final Long employeeId;
    private final String employeeCode;
    private final String employeeName;
    private final String email;
    private final String designation;
    private final EmployeeStatus status;
    private final Employee.EmployeeCategory category;
    private final LocalDate joiningDate;
    private final boolean enrolled;
    private final int activeEnrollmentCount;

    /**
     * Factory method to create DTO from Employee entity.
     * Category is dynamically resolved based on tenure.
     */
    public static EmployeeCoverageReportDTO fromEmployee(
            Employee employee,
            Employee.EmployeeCategory resolvedCategory,
            int activeEnrollmentCount) {

        return EmployeeCoverageReportDTO.builder()
                .employeeId(employee.getEmployeeId())
                .employeeCode(employee.getEmployeeCode())
                .employeeName(employee.getEmployeeName())
                .email(employee.getEmail())
                .designation(employee.getDesignation())
                .status(employee.getStatus())
                .category(resolvedCategory)
                .joiningDate(employee.getJoiningDate())
                .enrolled(activeEnrollmentCount > 0)
                .activeEnrollmentCount(activeEnrollmentCount)
                .build();
    }
}
