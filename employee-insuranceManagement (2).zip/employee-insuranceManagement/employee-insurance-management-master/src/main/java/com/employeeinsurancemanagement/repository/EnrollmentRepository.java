package com.employeeinsurancemanagement.repository;

import com.employeeinsurancemanagement.model.Enrollment;
import com.employeeinsurancemanagement.model.EnrollmentStatus;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.Organization;
import com.employeeinsurancemanagement.model.Policy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    Optional<Enrollment> findByEmployeeAndPolicy(Employee employee, Policy policy);

    boolean existsByEmployeeAndPolicyAndEnrollmentStatus(Employee employee, Policy policy, EnrollmentStatus status);

    List<Enrollment> findByEmployee(Employee employee);

    List<Enrollment> findByPolicy(Policy policy);

    List<Enrollment> findByEnrollmentStatus(EnrollmentStatus status);

    @org.springframework.data.jpa.repository.Query("SELECT COUNT(e) FROM Enrollment e WHERE e.enrollmentStatus = :status AND e.employee.organization = :organization")
    int countActiveEnrollmentsByOrganization(
            @org.springframework.data.repository.query.Param("status") EnrollmentStatus status,
            @org.springframework.data.repository.query.Param("organization") Organization organization);

    // For HR reports - count active enrollments per employee
    int countByEmployeeAndEnrollmentStatus(Employee employee, EnrollmentStatus status);
}
