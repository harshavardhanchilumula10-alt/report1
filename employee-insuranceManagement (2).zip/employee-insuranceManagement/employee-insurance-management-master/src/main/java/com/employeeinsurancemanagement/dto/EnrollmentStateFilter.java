package com.employeeinsurancemanagement.dto;

/**
 * Filter enum for enrollment state in HR reports.
 * Used instead of raw strings for type safety.
 */
public enum EnrollmentStateFilter {
    ALL,
    ENROLLED,
    NOT_ENROLLED
}
