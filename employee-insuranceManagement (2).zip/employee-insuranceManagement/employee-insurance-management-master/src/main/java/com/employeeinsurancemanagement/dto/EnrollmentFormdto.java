package com.employeeinsurancemanagement.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EnrollmentFormdto {

    @NotNull(message = "Employee ID is required")
    private Long employeeId;

    @NotNull(message = "Policy ID is required")
    private Long policyId;

    @NotBlank(message = "Nominee name is required")
    @Size(min = 2, max = 50, message = "Nominee name must be 2-50 characters")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Nominee name can only contain letters and spaces")
    private String nomineeName;

    @NotBlank(message = "Nominee relationship is required")
    @Pattern(regexp = "^(SPOUSE|CHILD|PARENT|SIBLING|OTHER)$", message = "Invalid nominee relationship")
    private String nomineeRelationship;

    private Double estimatedPremium;

    @Valid
    private List<DependentDTO> dependents = new java.util.ArrayList<>();
}
