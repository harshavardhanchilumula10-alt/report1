package com.employeeinsurancemanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependentDTO {

    @NotBlank(message = "Dependent name is required")
    @Size(min = 2, max = 50, message = "Dependent name must be 2-50 characters")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name can only contain letters and spaces")
    private String name;

    @NotBlank(message = "Relationship is required")
    @Pattern(regexp = "^(SPOUSE|CHILD|PARENT)$", message = "Relationship must be SPOUSE, CHILD, or PARENT")
    private String relation; // SPOUSE, CHILD, PARENT

    private int age;

    @NotNull(message = "Date of birth is required for dependent")
    @Past(message = "Date of birth must be in the past")
    @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
    private java.time.LocalDate dateOfBirth;

    public DependentDTO() {
    }

    public DependentDTO(String name, String relation, java.time.LocalDate dateOfBirth) {
        this.name = name;
        this.relation = relation;
        this.dateOfBirth = dateOfBirth;
        if (dateOfBirth != null) {
            this.age = java.time.Period.between(dateOfBirth, java.time.LocalDate.now()).getYears();
        }

    }

    public void setDateOfBirth(java.time.LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        if (dateOfBirth != null) {
            this.age = java.time.Period.between(dateOfBirth, java.time.LocalDate.now()).getYears();
        }
    }
}
