package com.employeeinsurancemanagement.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClaimRequest {

    @NotNull(message = "Enrollment ID is required")
    private Long enrollmentId;

    @NotNull(message = "Claim amount is required")
    @DecimalMin(value = "1000.0", message = "Claim amount must be at least ₹1000")
    private Double claimAmount;

    @NotBlank(message = "Claim reason is required")
    @Size(min = 3, message = "Claim reason must be at least 3 characters")
    private String claimReason;
}
