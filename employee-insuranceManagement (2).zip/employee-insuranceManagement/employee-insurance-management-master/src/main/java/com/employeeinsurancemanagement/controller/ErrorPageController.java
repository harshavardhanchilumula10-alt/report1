package com.employeeinsurancemanagement.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ErrorPageController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);

        String errorMessage = "An unexpected error occurred";
        String errorDetails = "Please try again or contact support if the problem persists";
        int statusCode = 500;

        if (status != null) {
            statusCode = Integer.parseInt(status.toString());

            if (statusCode == HttpStatus.NOT_FOUND.value()) {
                errorMessage = "Page Not Found";
                errorDetails = "The page you are looking for does not exist";
            } else if (statusCode == HttpStatus.FORBIDDEN.value()) {
                errorMessage = "Access Denied";
                errorDetails = "You do not have permission to access this resource";
            } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                errorMessage = "Internal Server Error";
                errorDetails = "Something went wrong on our end. Please try again later";
            } else if (statusCode == HttpStatus.BAD_REQUEST.value()) {
                errorMessage = "Bad Request";
                errorDetails = "The request could not be understood by the server";
            }
        }

        Exception exception = (Exception) request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
        if (exception != null) {
            errorDetails = exception.getMessage();
        }

        model.addAttribute("statusCode", statusCode);
        model.addAttribute("errorMessage", errorMessage);
        model.addAttribute("errorDetails", errorDetails);

        return "error/error";
    }
}