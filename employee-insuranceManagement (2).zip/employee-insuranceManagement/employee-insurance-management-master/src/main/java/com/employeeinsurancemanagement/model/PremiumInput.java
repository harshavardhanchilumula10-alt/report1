package com.employeeinsurancemanagement.model;

import com.employeeinsurancemanagement.dto.DependentDTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PremiumInput {

    private int age;
    private int tenureYears;
    private int pastClaimsCount;

    private double basePremium;
    private double coverageAmount;

    private PolicyType policyType;
    private Employee.EmployeeCategory category;

    private java.util.List<DependentDTO> dependents;
}
