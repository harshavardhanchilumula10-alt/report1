package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.model.Policy;

import java.util.List;

public interface PolicyService {

    Policy getPolicyById(Long policyId);

    List<Policy> getPoliciesByOrganization(Long organizationId);

    List<Policy> getAvailablePoliciesForEmployee(Long employeeId);

}
