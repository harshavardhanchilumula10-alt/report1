package com.employeeinsurancemanagement.repository;

import com.employeeinsurancemanagement.model.Claim;
import com.employeeinsurancemanagement.model.ClaimStatus;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {

  @Query("""
          SELECT COUNT(c)
          FROM Claim c
          WHERE c.enrollment = :enrollment
            AND c.claimStatus = :status
      """)
  int countClaimsByEnrollmentAndStatus(
      @Param("enrollment") Enrollment enrollment,
      @Param("status") ClaimStatus status);

  @Query("""
          SELECT COALESCE(SUM(c.claimAmount), 0)
          FROM Claim c
          WHERE c.enrollment = :enrollment
            AND c.claimStatus = :status
      """)
  double sumClaimAmountByEnrollmentAndStatus(
      @Param("enrollment") Enrollment enrollment,
      @Param("status") ClaimStatus status);

  @Query("""
          SELECT COALESCE(SUM(c.approvedAmount), 0)
          FROM Claim c
          WHERE c.enrollment.enrollmentId = :enrollmentId
            AND c.claimStatus = 'APPROVED'
      """)
  Double sumApprovedClaimsByEnrollmentId(@Param("enrollmentId") Long enrollmentId);

  List<Claim> findAllByEnrollment(Enrollment enrollment);

  List<Claim> findByEmployee(Employee employee);

  /**
   * Check if employee has an active (non-rejected) claim for a specific
   * enrollment.
   * Used to enforce one active claim per policy rule.
   */
  @Query("""
          SELECT COUNT(c) > 0
          FROM Claim c
          WHERE c.employee.employeeId = :employeeId
            AND c.enrollment.enrollmentId = :enrollmentId
            AND c.claimStatus IN (:activeStatuses)
      """)
  boolean existsActiveClaimForEnrollment(
      @Param("employeeId") Long employeeId,
      @Param("enrollmentId") Long enrollmentId,
      @Param("activeStatuses") List<ClaimStatus> activeStatuses);
}
