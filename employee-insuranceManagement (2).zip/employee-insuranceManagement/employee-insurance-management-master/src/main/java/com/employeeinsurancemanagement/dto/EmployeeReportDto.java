package com.employeeinsurancemanagement.dto;

import lombok.Getter;

@Getter
public class EmployeeReportDto {

    private final Long organizationId;
    private final String organizationName;
    private final Long employeeCount;

    public EmployeeReportDto(Long organizationId,
                             String organizationName,
                             Long employeeCount) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
        this.employeeCount = employeeCount;
    }
}

