package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.dto.PremiumReportDto;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ReportService {

  // DATA
  List<EmployeeReportDto> getEmployeeCountByOrganization(Long organizationId);

  @Query("""
      SELECT e.enrollmentId, COUNT(c),
       SUM(CASE WHEN c.claimStatus = 'APPROVED' THEN c.approvedAmount ELSE 0 END),
        SUM(CASE WHEN c.claimStatus = 'APPROVED' THEN 1 ELSE 0 END),
        SUM(CASE WHEN c.claimStatus = 'SUBMITTED' THEN 1 ELSE 0 END),
        SUM(CASE WHEN c.claimStatus = 'REJECTED' THEN 1 ELSE 0 END)
        FROM Enrollment e LEFT JOIN Claim c ON c.enrollment = e
        WHERE (:status IS NULL OR c.claimStatus = :status)
        GROUP BY e.enrollmentId
      """)
  List<ClaimReportDto> getClaimSummaryByEnrollment(String status);

  List<PremiumReportDto> getPremiumCollectedByOrganization(Long organizationId);

  // EXPORTS
  byte[] exportEmployeeReportExcel();

  byte[] exportEmployeeReportPdf();

  byte[] exportPremiumReportExcel(Long organizationId);

  byte[] exportPremiumReportPdf(Long organizationId);

  byte[] exportClaimReportExcel();

  byte[] exportClaimReportPdf();
}
