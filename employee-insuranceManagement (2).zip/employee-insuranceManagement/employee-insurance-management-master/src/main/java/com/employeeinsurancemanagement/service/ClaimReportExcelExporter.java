package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class ClaimReportExcelExporter {

    public byte[] export(List<ClaimReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook();
                ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Claims Summary");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Enrollment ID");
            header.createCell(1).setCellValue("Claim ID");
            header.createCell(2).setCellValue("Approved Amount");
            header.createCell(3).setCellValue("Claim Date");
            header.createCell(4).setCellValue("Status");

            int rowIdx = 1;
            for (ClaimReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEnrollmentId());
                if (dto.getClaimId() != null) {
                    row.createCell(1).setCellValue(dto.getClaimId());
                } else {
                    row.createCell(1).setCellValue("-");
                }

                Double amt = dto.getApprovedAmount();
                row.createCell(2).setCellValue(amt != null ? amt : 0.0);

                if (dto.getClaimDate() != null) {
                    row.createCell(3).setCellValue(dto.getClaimDate().toString());
                } else {
                    row.createCell(3).setCellValue("-");
                }

                row.createCell(4).setCellValue(dto.getClaimStatus());
            }

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
