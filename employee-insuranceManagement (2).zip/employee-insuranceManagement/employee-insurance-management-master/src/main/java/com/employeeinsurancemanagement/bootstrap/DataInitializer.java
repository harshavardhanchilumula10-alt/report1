package com.employeeinsurancemanagement.bootstrap;

import com.employeeinsurancemanagement.model.Organization;
import com.employeeinsurancemanagement.repository.OrganizationRepository;
import com.employeeinsurancemanagement.model.User;
import com.employeeinsurancemanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

        private final OrganizationRepository organizationRepository;
        private final UserRepository userRepository;
        private final PasswordEncoder passwordEncoder;

        @Override
        public void run(String... args) {

                Organization cognizant = createOrgIfNotExists("Cognizant", "COG");
                Organization wipro = createOrgIfNotExists("Wipro", "WIP");
                Organization zepto = createOrgIfNotExists("Zepto", "ZEP");

                // Policies are created via data.sql only - not programmatically

                createUserIfNotExists(
                                "admin@cognizant.com",
                                "admin123",
                                User.Role.ADMIN,
                                cognizant);

                createUserIfNotExists(
                                "hr@cognizant.com",
                                "hr123",
                                User.Role.HR,
                                cognizant);

                createUserIfNotExists(
                                "admin@wipro.com",
                                "admin123",
                                User.Role.ADMIN,
                                wipro);

                createUserIfNotExists(
                                "hr@wipro.com",
                                "hr123",
                                User.Role.HR,
                                wipro);

                createUserIfNotExists(
                                "admin@zepto.com",
                                "admin123",
                                User.Role.ADMIN,
                                zepto);

                createUserIfNotExists(
                                "hr@zepto.com",
                                "hr123",
                                User.Role.HR,
                                zepto);
        }

        private Organization createOrgIfNotExists(String name, String code) {
                return organizationRepository
                                .findByOrganizationName(name)
                                .orElseGet(() -> {
                                        Organization o = new Organization();
                                        o.setOrganizationName(name);
                                        o.setOrgCode(code);
                                        return organizationRepository.save(o);
                                });
        }

        private void createUserIfNotExists(
                        String email,
                        String rawPassword,
                        User.Role role,
                        Organization organization) {
                if (userRepository.findByEmail(email).isPresent()) {
                        return;
                }

                User user = new User();
                user.setEmail(email);
                user.setPassword(passwordEncoder.encode(rawPassword));
                user.setRole(role);
                user.setOrganization(organization);
                user.setActive(true);
                user.setFirstLogin(true); // important for password change flow

                userRepository.save(user);
        }

}
