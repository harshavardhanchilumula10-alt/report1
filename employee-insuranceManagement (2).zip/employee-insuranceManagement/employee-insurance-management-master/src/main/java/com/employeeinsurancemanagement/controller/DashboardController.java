package com.employeeinsurancemanagement.controller;

import com.employeeinsurancemanagement.model.User;
import com.employeeinsurancemanagement.repository.UserRepository;
import com.employeeinsurancemanagement.security.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserRepository userRepository;

    @GetMapping("/dashboard")
    public String dashboard() {
        String email = SecurityUtil.getCurrentUserEmail();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return switch (user.getRole()) {
            case ADMIN -> "redirect:/admin/dashboard";
            case HR -> "redirect:/hr/dashboard";
            case EMPLOYEE -> user.isFirstLogin() ? "redirect:/change-password" : "redirect:/employee/dashboard";
        };
    }
}