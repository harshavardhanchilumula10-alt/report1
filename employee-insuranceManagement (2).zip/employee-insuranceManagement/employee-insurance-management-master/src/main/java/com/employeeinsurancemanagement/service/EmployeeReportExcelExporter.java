package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.exception.ReportGenerationException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class EmployeeReportExcelExporter {

    public byte[] export(List<EmployeeReportDto> data) {

        try (Workbook workbook = new XSSFWorkbook();
                ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Employees");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Org ID");
            header.createCell(1).setCellValue("Org Name");
            header.createCell(2).setCellValue("Employee Count");

            int rowIdx = 1;
            for (EmployeeReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getOrganizationId());
                row.createCell(1).setCellValue(dto.getOrganizationName());
                row.createCell(2).setCellValue(dto.getEmployeeCount());
            }

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new ReportGenerationException("Excel generation failed", e);
        }
    }
}
