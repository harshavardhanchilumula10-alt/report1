package com.employeeinsurancemanagement.controller;

import com.employeeinsurancemanagement.dto.ClaimRequest;
import com.employeeinsurancemanagement.service.ClaimService;
import com.employeeinsurancemanagement.dto.EmployeeUpdateRequest;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.service.EmployeeService;
import com.employeeinsurancemanagement.dto.EnrollmentFormdto;
import com.employeeinsurancemanagement.service.EnrollmentService;
import com.employeeinsurancemanagement.model.Policy;

import com.employeeinsurancemanagement.model.User;
import com.employeeinsurancemanagement.repository.UserRepository;
import com.employeeinsurancemanagement.security.SecurityUtil;
import com.employeeinsurancemanagement.service.PolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/employee")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;
    private final EnrollmentService enrollmentService;
    private final ClaimService claimService;
    private final PolicyService policyService;
    private final UserRepository userRepository;

    private Employee getCurrentEmployee() {
        String email = SecurityUtil.getCurrentUserEmail();
        return employeeService.getEmployeeByEmail(email);
    }

    private Map<String, String> getHRContact(Employee employee) {
        // Find HR from the same organization
        Long orgId = employee.getOrganization().getOrganizationId();
        User hr = userRepository.findAll().stream()
                .filter(u -> u.getRole() == User.Role.HR &&
                        u.getOrganization().getOrganizationId().equals(orgId))
                .findFirst()
                .orElse(null);

        Map<String, String> contact = new HashMap<>();
        if (hr != null) {
            contact.put("name", "HR Department");
            contact.put("email", hr.getEmail());
        }
        return contact;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Employee employee = getCurrentEmployee();
        if (employee.getUser().isFirstLogin()) {
            return "redirect:/change-password";
        }

        model.addAttribute("employee", employee);
        model.addAttribute("enrollments", enrollmentService.getByEmployee(employee.getEmployeeId()));
        model.addAttribute("claims", claimService.getClaimsByEmployee(employee.getEmployeeId()));
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/dashboard";
    }

    @GetMapping("/policies")
    public String availablePolicies(Model model) {
        Employee employee = getCurrentEmployee();
        List<Policy> policies = policyService.getAvailablePoliciesForEmployee(employee.getEmployeeId());

        // Get enrolled policy IDs for this employee
        List<Long> enrolledPolicyIds = enrollmentService.getByEmployee(employee.getEmployeeId())
                .stream()
                .map(e -> e.getPolicy().getPolicyId())
                .toList();

        model.addAttribute("employee", employee);
        model.addAttribute("policies", policies);
        model.addAttribute("enrolledPolicyIds", enrolledPolicyIds);
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/policies";
    }

    @GetMapping("/policies/enroll")
    public String showEnrollmentForm(@RequestParam Long policyId, Model model) {
        Employee employee = getCurrentEmployee();
        Policy policy = policyService.getPolicyById(policyId);

        model.addAttribute("employee", employee);
        model.addAttribute("policy", policy);
        EnrollmentFormdto form = new EnrollmentFormdto();
        form.setEmployeeId(employee.getEmployeeId());
        model.addAttribute("enrollmentForm", form);
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/enrollmentForm";
    }

    @GetMapping("/enrollments")
    public String myEnrollments(Model model) {
        Employee employee = getCurrentEmployee();

        model.addAttribute("employee", employee);
        model.addAttribute("enrollments", enrollmentService.getByEmployee(employee.getEmployeeId()));
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/enrollments";
    }

    @GetMapping("/claims")
    public String claims(Model model) {
        Employee employee = getCurrentEmployee();

        model.addAttribute("employee", employee);
        model.addAttribute("claims", claimService.getClaimsByEmployee(employee.getEmployeeId()));
        model.addAttribute("enrollments", enrollmentService.getByEmployee(employee.getEmployeeId()));
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/claims";
    }

    @GetMapping("/submit-claim")
    public String submitClaimForm(Model model) {
        Employee employee = getCurrentEmployee();

        model.addAttribute("employee", employee);
        model.addAttribute("enrollments", enrollmentService.getByEmployee(employee.getEmployeeId()));
        model.addAttribute("claimRequest", new ClaimRequest());
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/submit-claim";
    }

    @PostMapping("/submit-claim")
    public String submitClaim(
            @Valid @ModelAttribute("claimRequest") ClaimRequest claimRequest,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model) {

        Employee employee = getCurrentEmployee();

        if (bindingResult.hasErrors()) {
            // Reload page with errors
            model.addAttribute("employee", employee);
            model.addAttribute("enrollments", enrollmentService.getByEmployee(employee.getEmployeeId()));
            model.addAttribute("hrContact", getHRContact(employee));
            return "employee/submit-claim";
        }

        claimService.submitClaim(employee.getEmployeeId(), claimRequest.getEnrollmentId(),
                claimRequest.getClaimAmount(), claimRequest.getClaimReason());
        redirectAttributes.addFlashAttribute("success", "Claim submitted successfully. Pending admin approval.");
        return "redirect:/employee/claims";
    }

    @GetMapping("/profile")
    public String profile(Model model) {
        Employee employee = employeeService.getEmployeeById(getCurrentEmployee().getEmployeeId());

        if (employee.getDateOfBirth() != null) {
            int age = java.time.Period.between(employee.getDateOfBirth(), java.time.LocalDate.now()).getYears();
            model.addAttribute("age", age);
        } else {
            model.addAttribute("age", "N/A");
        }

        model.addAttribute("employee", employee);
        model.addAttribute("employeeUpdateRequest", new EmployeeUpdateRequest());
        model.addAttribute("hrContact", getHRContact(employee));

        return "employee/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(
            @Valid @ModelAttribute EmployeeUpdateRequest updateRequest,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Validation failed. Please check your input.");
            return "redirect:/employee/profile";
        }

        Employee employee = getCurrentEmployee();
        employeeService.updateEmployee(employee.getEmployeeId(), updateRequest);
        redirectAttributes.addFlashAttribute("success", "Profile updated successfully.");

        return "redirect:/employee/profile";
    }
}