package com.employeeinsurancemanagement.repository;

import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.model.Organization;
import com.employeeinsurancemanagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("""
                SELECT coalesce(max(e.employeeSeq), 0)
                FROM Employee e
                WHERE e.organization = :org
            """)
    Long findMaxSeqByOrganization(@Param("org") Organization org);

    Optional<Employee> findByUser(User user);

    Optional<Employee> findByEmail(String email);

    boolean existsByPhoneNumber(Long phoneNumber);

    // For HR reports - find all employees by organization
    List<Employee> findByOrganizationOrganizationId(Long organizationId);
}
